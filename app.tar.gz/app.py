from flask import Flask, request,render_template#import main Flask class and request object
import json
import requests

app = Flask(__name__) #create the Flask app


@app.route('/')
def home():
    return render_template("a.html")

@app.route('/es',methods=['GET', 'POST'])
def query_example():
    product = request.args.get("product")
    if product:
       data={"suggest":{"product-suggest":{"prefix": product,"completion":{"field":"name.completion"}}}}
       header = {"Content-Type": "application/json"}
       r=requests.post("http://localhost:9200/product/_search",data=json.dumps(data),headers=header)

       result = [i['_source']['name'] for i in json.loads(r.text)['suggest']['product-suggest'][0]['options']]
       return json.dumps(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True, port=9100) #run app in debug mode on port 5000
